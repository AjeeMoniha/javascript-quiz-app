var allQuestions = [{
    id: "Javascript",
    question: "Which is used to put the JavaScript code?",
    a: "<javascript>",
    b: "<js>",
    c: "<scripting>",
    d: "<script>",
    correct: "<script>",
}, {
    id: "Javascript",
    question: "What are the closures?",
    a: "Both Function objects and Scope",
    b: "Scope where function's variables are resolved",
    c: "Function objects",
    d: "Function return value",
    correct: "Function objects",
}, {
    id: "HTML",
    question: "HTML stands for?",
    a: "Hypertext Machine language",
    b: "Hypertext and links markup language",
    c: "Hypertext Markup Language",
    d: "Hightext machine language",
    correct: "Hypertext Markup Language",
}, {
    id: "Javascript",
    question: "Which language runs in a web browser?",
    a: "Java",
    b: "C",
    c: "Python",
    d: "Javascript",
    correct: "Javascript",
}, {
    id: "Javascript",
    question: "Which is not a JavaScript Data Types?",
    a: "Boolean",
    b: "Float",
    c: "Undefined",
    d: "Number",
    correct: "Float",
}, {
    id: "Javascript",
    question: "Types of Pop up boxes in JavaScript?",
    a: "Alert",
    b: "Prompt",
    c: "Confirm",
    d: "All of the above",
    correct: "All of the above",
}, {
    id: "HTML",
    question: "HTML tags are enclosed in?",
    a: "# and #",
    b: "{ and }",
    c: "! and ?",
    d: "< and >",
    correct: "< and >",
}, {
    id: "HTML",
    question: "What is the purpose of div tags in HTML?",
    a: "For creating Different styles",
    b: "For creating different sections",
    c: "For adding headings",
    d: "For adding titles",
    correct: "For creating different sections",
}, {
    id: "HTML",
    question: "HTML can be rendered and read by?",
    a: "Web browser",
    b: "Server",
    c: "Interpreter",
    d: "None of the above",
    correct: "Web browser",
}, {
    id: "HTML",
    question: "HTML tag to display scrolling effect?",
    a: "<scroll>",
    b: "<marquee>",
    c: "<div>",
    d: "None of the above",
    correct: "<marquee>",
}, {
    id: "CSS",
    question: "Abbreviation of CSS ?",
    a: "Cascade sheets style",
    b: "Color and style sheets",
    c: "Cascading style sheets",
    d: "Coded Style Sheet",
    correct: "Cascading style sheets",
}, {
    id: "CSS",
    question: "In how many ways can CSS be written in?",
    a: "1",
    b: "2",
    c: "3",
    d: "4",
    correct: "3",
}, {
    id: "CSS",
    question: "How can we write comments in CSS?",
    a: "/* */",
    b: "//",
    c: "#",
    d: "All of the above",
    correct: "/* */",
}, {
    id: "CSS",
    question: "What are the types of gradients in CSS?",
    a: "Linear gradients",
    b: "Conic gradients",
    c: "Radial gradients",
    d: "All of the above",
    correct: "All of the above",
}, {
    id: "CSS",
    question: "CSS property to create an image reflection?",
    a: "Box-reflect",
    b: "Image-reflect",
    c: "Reflect-img",
    d: "None of the above",
    correct: "Box-reflect",
},];
//dropdown
var drop = [{ title1: "Javascript", title2: "HTML", title3: "CSS" }];
//instructions
var instruct = [
    {
        first: "Total Score for this Quiz is 10 Marks.",
        second: "Quiz contains 5 questions.",
        third: "There are four option. Select one to know your answer is right or wrong.",
        fourth: "Each correct attempt carry 2 marks.",
        fifth: "Note: Total time to complete this quiz is 30 seconds.",
    }
];
var i = 0;
//dropdown
var drop1 = document.querySelector("#js");
var drop2 = document.querySelector("#ht");
var drop3 = document.querySelector("#cs");
drop1.innerText = drop[i].title1;
drop2.innerText = drop[i].title2;
drop3.innerText = drop[i].title3;
//instruction
var list1 = document.querySelector(".one");
var list2 = document.querySelector(".two");
var list3 = document.querySelector(".three");
var list4 = document.querySelector(".four");
var list5 = document.querySelector(".five");
list1.innerText = instruct[i].first;
list2.innerText = instruct[i].second;
list3.innerText = instruct[i].third;
list4.innerText = instruct[i].fourth;
list5.innerText = instruct[i].fifth;
//questions and options
var res = [0];
var questions = document.querySelector(".quest");
var option1 = document.getElementById("a");
var option2 = document.getElementById("b");
var option3 = document.getElementById("c");
var option4 = document.getElementById("d");
var answers = document.querySelector(".answer");
var submitBtn = document.querySelector(".submit");
var num = 0;
var check1;
var check2;
var check3;
var check4;
var check;
var score = 0;
var add;
var select;
var selectedChoice;
var call;
var click;
submitBtn.addEventListener("click", submitClicked);
function submitClicked() {
    for (; i < allQuestions.length;) {
        if (selectedChoice !== allQuestions[i].id) {
            i++;
        }
        else {
            call = i;
            num += 1;
            tot = num;
            document.getElementById("no").innerText = tot;
            questions.innerText = allQuestions[i].question;
            option1.innerText = allQuestions[i].a;
            option2.innerText = allQuestions[i].b;
            option3.innerText = allQuestions[i].c;
            option4.innerText = allQuestions[i].d;
            document.getElementById('a').style.background = "#efefef";
            document.getElementById('b').style.background = "#efefef";
            document.getElementById('c').style.background = "#efefef";
            document.getElementById('d').style.background = "#efefef";
            i++;
            return i;
        }
    }
    document.getElementById("show").style.display = 'block';
    document.querySelector(".wrapper").style.display = 'none';
    adds();
}
function adds() {
    add = res.pop();//res[res.length - 1];// take score
    document.getElementById("ans").innerText = add;
    localStorage.setItem('Your Score', add); //local storage 
}
function myFunction1() {
    check1 = document.getElementById('a').innerText;
    check2 = document.getElementById('b').innerText;
    check3 = document.getElementById('c').innerText;
    check4 = document.getElementById('d').innerText;
    check = allQuestions[call].correct;
    if (check == check1) {
        score += 2;
        res.push(score);
        document.getElementById('a').style.background = "#82ec9f";
    }
    else {
        document.getElementById('a').style.background = "#eb6047";
    }
    if (check == check2) {
        document.getElementById('b').style.background = "#82ec9f";
    }
    else if (check == check3) {
        document.getElementById('c').style.background = "#82ec9f";
    } else if (check == check4) {
        document.getElementById('d').style.background = "#82ec9f";
    } else {

    }
};
function myFunction2() {
    check1 = document.getElementById('a').innerText;
    check2 = document.getElementById('b').innerText;
    check3 = document.getElementById('c').innerText;
    check4 = document.getElementById('d').innerText;
    check = allQuestions[call].correct;
    if (check == check2) {
        score += 2;
        res.push(score);
        document.getElementById('b').style.background = "#82ec9f";
    }
    else {
        document.getElementById('b').style.background = "#eb6047";
    }

    if (check == check1) {
        document.getElementById('a').style.background = "#82ec9f";
    }
    else if (check == check3) {
        document.getElementById('c').style.background = "#82ec9f";
    } else if (check == check4) {
        document.getElementById('d').style.background = "#82ec9f";
    } else {

    }
};
function myFunction3() {
    check1 = document.getElementById('a').innerText;
    check2 = document.getElementById('b').innerText;
    check3 = document.getElementById('c').innerText;
    check4 = document.getElementById('d').innerText;
    check = allQuestions[call].correct;
    if (check == check3) {
        score += 2;
        res.push(score);
        document.getElementById('c').style.background = "#82ec9f";
    }
    else {
        document.getElementById('c').style.background = "#eb6047";
    }

    if (check == check1) {
        document.getElementById('a').style.background = "#82ec9f";
    }
    else if (check == check2) {
        document.getElementById('b').style.background = "#82ec9f";
    } else if (check == check4) {
        document.getElementById('d').style.background = "#82ec9f";
    } else {
    }
};
function myFunction4() {
    check1 = document.getElementById('a').innerText;
    check2 = document.getElementById('b').innerText;
    check3 = document.getElementById('c').innerText;
    check4 = document.getElementById('d').innerText;
    check = allQuestions[call].correct;
    if (check == check4) {
        score += 2;
        res.push(score);
        document.getElementById('d').style.background = "#82ec9f";
    }
    else {
        document.getElementById('d').style.background = "#eb6047";
    }
    if (check == check1) {
        document.getElementById('a').style.background = "#82ec9f";
    }
    else if (check == check2) {
        document.getElementById('b').style.background = "#82ec9f";
    } else if (check == check3) {
        document.getElementById('c').style.background = "#82ec9f";
    } else {
    }
};
//instruction
function done() { //dropdown Done button
    select = document.querySelector("select");
    selectedChoice = select.value;
    document.querySelector('#topic').innerText = selectedChoice;
    document.querySelector('#topics').innerText = selectedChoice;

    document.querySelector("#dropdown").style.display = "none";
    document.querySelector("#first").style.display = 'block';
    document.querySelector(".wrapper").style.display = 'none';
    document.getElementById("show").style.display = 'none';

    click = document.querySelector("input").value;
    localStorage.setItem('Name', click);//local storage
    localStorage.setItem('Selected Quiz', selectedChoice); //local storage
}
function clock() {
    document.querySelector("#first").style.display = 'none';
    document.querySelector(".wrapper").style.display = 'block';
    document.getElementById("show").style.display = 'none';
    document.querySelector("#dropdown").style.display = "none";
    //timer
    var count = 30;
    var interval = setInterval(function () {
        count--;
        document.getElementById('count').innerHTML = count;
        if (count == 0) {
            clearInterval(interval); //clear a timer
            adds();
            document.querySelector(".wrapper").style.display = 'none';
            document.getElementById("show").style.display = 'block';
            document.querySelector("#dropdown").style.display = "none";
            document.querySelector("#first").style.display = 'none';
        }
    }, 1000);
}
